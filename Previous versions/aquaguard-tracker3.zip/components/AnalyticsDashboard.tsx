
import React, { useState, useMemo } from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, ResponsiveContainer, 
  Legend, Radar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis
} from 'recharts';
import { WaterSample, MetricKey, METRIC_LABELS, SAMPLERS } from '../types';
import { calculateStats } from '../utils/statistics';
import { calculateDistance } from '../utils/geo';
import { 
  BarChart3, Sparkles, Loader2, UserCheck, 
  LineChart as LineIcon, GitCompare, Trophy, Award, Medal, Clock, MapPin
} from 'lucide-react';
import { GoogleGenAI } from '@google/genai';

interface AnalyticsProps {
  samples: WaterSample[];
}

const AnalyticsDashboard: React.FC<AnalyticsProps> = ({ samples }) => {
  const [activeSubTab, setActiveSubTab] = useState<'stats' | 'performance' | 'integrity' | 'comparative'>('integrity');
  const [selectedMetric, setSelectedMetric] = useState<MetricKey>('chlorine');
  const [aiInsight, setAiInsight] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const dataValues = useMemo(() => samples.map(s => s.metrics[selectedMetric]), [samples, selectedMetric]);
  const stats = useMemo(() => calculateStats(dataValues), [dataValues]);
  
  const histogramData = useMemo(() => {
    if (dataValues.length === 0 || !stats) return [];
    const min = stats.min;
    const max = stats.max;
    const range = max - min;
    const bins = 8;
    const binSize = range / bins;
    const histogram = Array(bins).fill(0).map((_, i) => ({
      range: binSize === 0 ? min.toFixed(2) : `${(min + i * binSize).toFixed(2)}`,
      count: 0
    }));
    dataValues.forEach(v => {
      let index = binSize === 0 ? 0 : Math.floor((v - min) / binSize);
      if (index >= bins) index = bins - 1;
      if (index < 0) index = 0;
      histogram[index].count++;
    });
    return histogram;
  }, [dataValues, stats]);

  const rankingData = useMemo(() => {
    const metricsKeys = Object.keys(METRIC_LABELS) as MetricKey[];
    const results = SAMPLERS.map(samplerId => {
      const samplerSamples = samples
        .filter(s => s.samplerId === samplerId)
        .sort((a, b) => a.timestamp - b.timestamp);
      
      if (samplerSamples.length === 0) return { samplerId, globalScore: 0, totalSamples: 0, flags: [], avgTime: 0, avgDist: 0 };

      let totalIntegrity = 0;
      const allFlags: string[] = [];
      const validIntervals: { time: number; dist: number }[] = [];

      metricsKeys.forEach(key => {
        let metricPenalty = 0;
        const populationStats = calculateStats(samples.map(s => s.metrics[key]));
        const samplerMetrics = samplerSamples.map(s => s.metrics[key]);
        const samplerStats = calculateStats(samplerMetrics);

        if (samplerStats && populationStats && populationStats.stdDev > 0) {
          const varianceRatio = samplerStats.stdDev / populationStats.stdDev;
          if (varianceRatio < 0.25 && samplerSamples.length > 4) metricPenalty += 20;
          const devPercent = Math.abs(samplerStats.mean - populationStats.mean) / (populationStats.mean || 1);
          if (devPercent > 0.4 && samplerSamples.length > 5) metricPenalty += 15;
          if (!samplerStats.isNormal && populationStats.isNormal) metricPenalty += 10;
        }
        totalIntegrity += Math.max(0, 100 - metricPenalty);
      });

      let spatialPenalty = 0;
      for (let i = 1; i < samplerSamples.length; i++) {
        const s1 = samplerSamples[i-1];
        const s2 = samplerSamples[i];
        const dist = calculateDistance(s1.location.lat, s1.location.lng, s2.location.lat, s2.location.lng);
        const timeDiff = (s2.timestamp - s1.timestamp) / (1000 * 60);

        if (timeDiff <= 20 && dist <= 1000) {
          validIntervals.push({ time: timeDiff, dist: dist });
        }

        if (timeDiff > 0 && (dist / 1000) / (timeDiff / 60) > 130) {
          allFlags.push("سرعت غیرمجاز");
          spatialPenalty = 25;
          break;
        }
      }

      const avgTime = validIntervals.length > 0 ? validIntervals.reduce((a, b) => a + b.time, 0) / validIntervals.length : 0;
      const avgDist = validIntervals.length > 0 ? validIntervals.reduce((a, b) => a + b.dist, 0) / validIntervals.length : 0;
      const finalGlobalScore = Math.max(0, (totalIntegrity / metricsKeys.length) - spatialPenalty);

      return { 
        samplerId, 
        globalScore: finalGlobalScore, 
        totalSamples: samplerSamples.length, 
        flags: allFlags,
        avgTime,
        avgDist
      };
    });
    return results.sort((a, b) => b.globalScore - a.globalScore);
  }, [samples]);

  const getAIInsight = async () => {
    if (!process.env.API_KEY || process.env.API_KEY === '') {
      setAiInsight("خطا: کلید API یافت نشد.");
      return;
    }
    setIsAnalyzing(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const rankingText = rankingData.map((d, i) => `${i+1}. ${d.samplerId} (${d.globalScore.toFixed(1)}%)`).join(' | ');
      const prompt = `Water quality audit analyst report for: ${rankingText}. Write a brief forensic summary in Persian. 2 sentences max.`;
      const response = await ai.models.generateContent({ model: 'gemini-3-flash-preview', contents: prompt });
      setAiInsight(response.text || "پاسخی دریافت نشد.");
    } catch (e) {
      setAiInsight("خطا در ارتباط با هوش مصنوعی.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const samplerColors: Record<string, string> = {
    'محمدرضا ابتکاری': '#3b82f6',
    'ابوالفضل شرقی': '#8b5cf6',
    'سعید محرری': '#ec4899',
  };

  const samplerRadarData = useMemo(() => {
    const metricsKeys = Object.keys(METRIC_LABELS) as MetricKey[];
    return metricsKeys.map(key => {
      const obj: any = { subject: METRIC_LABELS[key] };
      SAMPLERS.forEach(sampler => {
        const samplerVals = samples.filter(s => s.samplerId === sampler).map(s => s.metrics[key]);
        const samplerAvg = samplerVals.length > 0 ? samplerVals.reduce((a, b) => a + b, 0) / samplerVals.length : 0;
        const totalAvg = samples.map(s => s.metrics[key]).reduce((a, b) => a + b, 0) / (samples.length || 1);
        obj[sampler] = totalAvg === 0 ? 0 : (samplerAvg / totalAvg) * 100;
      });
      return obj;
    });
  }, [samples]);

  return (
    <div className="space-y-6">
      <div className="flex bg-gray-100 p-1 rounded-xl w-full sm:w-max overflow-x-auto no-scrollbar">
        <button onClick={() => setActiveSubTab('integrity')} className={`flex-none px-6 py-2 rounded-lg text-sm font-bold transition flex items-center gap-2 ${activeSubTab === 'integrity' ? 'bg-white shadow text-red-600' : 'text-gray-500'}`}>
          <Trophy className="w-4 h-4" /> رتبه‌بندی
        </button>
        <button onClick={() => setActiveSubTab('comparative')} className={`flex-none px-6 py-2 rounded-lg text-sm font-bold transition flex items-center gap-2 ${activeSubTab === 'comparative' ? 'bg-white shadow text-indigo-600' : 'text-gray-500'}`}>
          <GitCompare className="w-4 h-4" /> مقایسه سیستمی
        </button>
        <button onClick={() => setActiveSubTab('stats')} className={`flex-none px-6 py-2 rounded-lg text-sm font-bold transition flex items-center gap-2 ${activeSubTab === 'stats' ? 'bg-white shadow text-blue-600' : 'text-gray-500'}`}>
          <BarChart3 className="w-4 h-4" /> توزیع آماری
        </button>
        <button onClick={() => setActiveSubTab('performance')} className={`flex-none px-6 py-2 rounded-lg text-sm font-bold transition flex items-center gap-2 ${activeSubTab === 'performance' ? 'bg-white shadow text-purple-600' : 'text-gray-500'}`}>
          <UserCheck className="w-4 h-4" /> ممیزی فردی
        </button>
      </div>

      <div className="bg-white p-4 rounded-xl shadow border border-gray-100 flex items-center justify-between flex-wrap gap-4">
        <h2 className="text-xl font-bold flex items-center gap-2">
            {activeSubTab === 'integrity' ? <><Award className="text-red-600 w-5 h-5"/> سکوی اعتبار داده‌ها</> : <><LineIcon className="text-blue-600 w-5 h-5"/> داشبورد تحلیلی</>}
        </h2>
        <div className="flex gap-3">
          <button onClick={getAIInsight} disabled={isAnalyzing} className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition disabled:opacity-50 text-xs font-bold shadow-sm">
              {isAnalyzing ? <Loader2 className="w-3 h-3 animate-spin"/> : <Sparkles className="w-3 h-3"/>} گزارش هوشمند
          </button>
          <select value={selectedMetric} onChange={(e) => setSelectedMetric(e.target.value as MetricKey)} className="p-2 border rounded-lg bg-gray-50 text-xs font-bold outline-none">
                {(Object.keys(METRIC_LABELS) as MetricKey[]).map(k => <option key={k} value={k}>{METRIC_LABELS[k]}</option>)}
          </select>
        </div>
      </div>

      {aiInsight && (
        <div className="bg-red-50 border-r-4 border-red-600 p-4 rounded-lg">
            <p className="text-sm leading-relaxed text-red-900 font-medium">{aiInsight}</p>
        </div>
      )}

      {activeSubTab === 'integrity' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-end pt-10">
          <RankingCard rank={2} data={rankingData[1]} color="border-gray-200 bg-gray-50/30" icon={<Medal className="w-10 h-10 text-gray-400" />} badgeColor="bg-gray-400" />
          <div className="relative -top-6">
            <RankingCard rank={1} data={rankingData[0]} color="border-yellow-400 ring-8 ring-yellow-50 bg-yellow-50/20" icon={<Trophy className="w-16 h-16 text-yellow-500" />} badgeColor="bg-yellow-500" isWinner />
          </div>
          <RankingCard rank={3} data={rankingData[2]} color="border-orange-100 bg-orange-50/10" icon={<Award className="w-10 h-10 text-orange-400" />} badgeColor="bg-orange-600" />
        </div>
      )}

      {activeSubTab === 'performance' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {rankingData.map(perf => (
            <div key={perf.samplerId} className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex flex-col items-center">
              <div className="w-16 h-16 bg-blue-50 rounded-full flex items-center justify-center mb-4"><UserCheck className="w-8 h-8 text-blue-600" /></div>
              <h4 className="font-black text-gray-800 mb-4">{perf.samplerId}</h4>
              <div className="w-full bg-gray-50 p-4 rounded-xl space-y-2 text-[10px]">
                <div className="flex justify-between"><span className="text-gray-500">شاخص اعتبار:</span><span className="font-bold text-green-600">{perf.globalScore.toFixed(1)}%</span></div>
                <div className="flex justify-between"><span className="text-gray-500">متوسط زمان (دقیقه):</span><span className="font-bold">{perf.avgTime.toFixed(1)}</span></div>
                <div className="flex justify-between"><span className="text-gray-500">متوسط فاصله (متر):</span><span className="font-bold">{Math.round(perf.avgDist)}</span></div>
                <div className="flex justify-between pt-2 border-t"><span className="text-gray-500">تعداد نمونه:</span><span className="font-bold">{perf.totalSamples}</span></div>
              </div>
            </div>
          ))}
        </div>
      )}

      {activeSubTab === 'comparative' && (
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 h-96">
          <ResponsiveContainer width="100%" height="100%">
            <RadarChart data={samplerRadarData}>
              <PolarGrid stroke="#e2e8f0" />
              <PolarAngleAxis dataKey="subject" fontSize={10} />
              <PolarRadiusAxis angle={30} domain={[0, 150]} hide />
              {SAMPLERS.map(s => <Radar key={s} name={s} dataKey={s} stroke={samplerColors[s]} fill={samplerColors[s]} fillOpacity={0.2} />)}
              <Legend />
              <RechartsTooltip />
            </RadarChart>
          </ResponsiveContainer>
        </div>
      )}

      {activeSubTab === 'stats' && (
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 h-80">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={histogramData}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="range" fontSize={10} />
              <YAxis hide />
              <RechartsTooltip />
              <Bar dataKey="count" fill="#3b82f6" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}
    </div>
  );
};

const RankingCard: React.FC<{ rank: number; data: any; color: string; icon: React.ReactNode; badgeColor: string; isWinner?: boolean }> = ({ rank, data, color, icon, badgeColor, isWinner }) => (
  <div className={`relative p-8 rounded-[2.5rem] shadow-2xl border-4 flex flex-col items-center transition-all duration-300 ${color}`}>
    <div className={`absolute -top-6 left-1/2 -translate-x-1/2 w-12 h-12 rounded-full flex items-center justify-center text-white font-black text-xl shadow-xl ring-4 ring-white ${badgeColor}`}>{rank}</div>
    <div className="mb-6">{icon}</div>
    <h3 className="text-xl font-black text-gray-800 mb-2">{data?.samplerId || 'درحال محاسبه'}</h3>
    <div className="grid grid-cols-2 gap-2 w-full mb-6">
        <div className="bg-white/50 p-2 rounded-xl flex flex-col items-center"><Clock className="w-3 h-3 text-blue-500" /><span className="text-[8px] text-gray-400">زمان</span><span className="text-xs font-black">{data?.avgTime?.toFixed(1) || '0'}m</span></div>
        <div className="bg-white/50 p-2 rounded-xl flex flex-col items-center"><MapPin className="w-3 h-3 text-red-500" /><span className="text-[8px] text-gray-400">فاصله</span><span className="text-xs font-black">{Math.round(data?.avgDist || 0)}m</span></div>
    </div>
    <div className={`text-4xl font-black ${isWinner ? 'text-yellow-600' : 'text-gray-700'}`}>{data?.globalScore?.toFixed(1) || '0.0'}%</div>
  </div>
);

export default AnalyticsDashboard;
