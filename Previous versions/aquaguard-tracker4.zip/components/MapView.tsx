
import React, { useRef, useState, useMemo } from 'react';
import { MapContainer, TileLayer, CircleMarker, Popup, Polyline } from 'react-leaflet';
import L from 'leaflet';
import { WaterSample, SAMPLERS } from '../types';
import { Share2, Map as MapIcon, Camera, Loader2, Filter, Users } from 'lucide-react';
import { toPng } from 'html-to-image';

// Fix Leaflet Default Icon in React
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png',
});

interface MapViewProps {
  samples: WaterSample[];
}

const samplerColors: Record<string, string> = {
  'محمدرضا ابتکاری': '#3b82f6',
  'ابوالفضل شرقی': '#8b5cf6',
  'سعید محرری': '#ec4899',
};

const MapView: React.FC<MapViewProps> = ({ samples }) => {
  const [visualMode, setVisualMode] = useState<'standard' | 'heatmap'>('standard');
  const [selectedSampler, setSelectedSampler] = useState<string>('all');
  const [isCapturing, setIsCapturing] = useState(false);
  const mapRef = useRef<L.Map | null>(null);
  const mapContainerRef = useRef<HTMLDivElement>(null);

  const filteredSamples = useMemo(() => {
    if (selectedSampler === 'all') return samples;
    return samples.filter(s => s.samplerId === selectedSampler);
  }, [samples, selectedSampler]);

  const defaultCenter: [number, number] = [35.6892, 51.3890];
  const center = filteredSamples.length > 0 
    ? [filteredSamples[0].location.lat, filteredSamples[0].location.lng] as [number, number]
    : defaultCenter;

  const getQualityColor = (s: WaterSample) => {
    if (s.metrics.turbidity > 5 || s.metrics.chlorine < 0.2) return '#ef4444'; 
    if (s.metrics.turbidity > 1 || s.metrics.chlorine < 0.5) return '#f59e0b'; 
    return '#10b981'; 
  };

  // Group paths by Sampler AND Day
  const dailyPaths = useMemo(() => {
    const paths: { color: string; positions: [number, number][]; label: string }[] = [];
    const grouped: Record<string, Record<string, WaterSample[]>> = {};
    
    filteredSamples.forEach(s => {
      const date = new Date(s.timestamp).toLocaleDateString('en-CA'); 
      if (!grouped[s.samplerId]) grouped[s.samplerId] = {};
      if (!grouped[s.samplerId][date]) grouped[s.samplerId][date] = [];
      grouped[s.samplerId][date].push(s);
    });

    Object.entries(grouped).forEach(([sampler, dates]) => {
      Object.entries(dates).forEach(([date, daySamples]) => {
        const sorted = [...daySamples].sort((a, b) => a.timestamp - b.timestamp);
        if (sorted.length > 1) {
          paths.push({
            color: samplerColors[sampler] || '#cccccc',
            positions: sorted.map(s => [s.location.lat, s.location.lng] as [number, number]),
            label: `${sampler} - ${date}`
          });
        }
      });
    });
    return paths;
  }, [filteredSamples]);

  const handleShare = () => {
    const url = window.location.href;
    navigator.clipboard.writeText(url);
    alert("لینک اشتراک‌گذاری کپی شد!");
  };

  const handleCapture = async () => {
    if (!mapContainerRef.current) return;
    setIsCapturing(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 200));
      const dataUrl = await toPng(mapContainerRef.current, {
        cacheBust: true,
        backgroundColor: '#ffffff'
      });
      const link = document.createElement('a');
      link.download = `aquaguard-map-${new Date().getTime()}.png`;
      link.href = dataUrl;
      link.click();
    } catch (error) {
      console.error('Map capture failed:', error);
      alert("خطا در تهیه تصویر از نقشه.");
    } finally {
      setIsCapturing(false);
    }
  };

  return (
    <div className="bg-white p-4 rounded-xl shadow-lg border border-gray-100 h-[700px] flex flex-col">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-4 gap-4">
        <div className="flex flex-col gap-2">
          <h2 className="text-xl font-bold text-gray-800 flex items-center gap-2">
            <MapIcon className="text-blue-600 w-5 h-5"/> نقشه پایش و تراکم
          </h2>
          <div className="flex bg-gray-100 p-1 rounded-lg w-fit">
            <button
              onClick={() => setVisualMode('standard')}
              className={`px-4 py-1.5 text-xs font-bold rounded-md transition ${visualMode === 'standard' ? 'bg-white shadow text-blue-600' : 'text-gray-500'}`}
            >
              نمای استاندارد
            </button>
            <button
              onClick={() => setVisualMode('heatmap')}
              className={`px-4 py-1.5 text-xs font-bold rounded-md transition ${visualMode === 'heatmap' ? 'bg-white shadow text-red-600' : 'text-gray-500'}`}
            >
              نقشه حرارتی
            </button>
          </div>
        </div>

        <div className="flex items-center gap-3 flex-wrap">
          <div className="flex items-center gap-2 bg-gray-50 px-3 py-2 rounded-xl border border-gray-200">
            <Users className="w-4 h-4 text-gray-400" />
            <select 
              value={selectedSampler} 
              onChange={(e) => setSelectedSampler(e.target.value)}
              className="bg-transparent text-xs font-bold outline-none"
            >
              <option value="all">تمام نمونه‌بردارها</option>
              {SAMPLERS.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>

          <div className="flex gap-1 bg-gray-50 rounded-full p-1 border border-gray-100">
            <button 
              onClick={handleCapture} 
              disabled={isCapturing}
              className={`p-2.5 rounded-full transition flex items-center justify-center ${isCapturing ? 'text-blue-300' : 'text-gray-600 hover:bg-white hover:shadow-sm'}`} 
              title="کپچر نقشه (PNG)"
            >
                {isCapturing ? <Loader2 className="w-5 h-5 animate-spin"/> : <Camera className="w-5 h-5"/>}
            </button>
            <button onClick={handleShare} className="p-2.5 text-gray-600 hover:bg-white hover:shadow-sm rounded-full transition" title="اشتراک‌گذاری">
                <Share2 className="w-5 h-5"/>
            </button>
          </div>
        </div>
      </div>

      <div ref={mapContainerRef} className="flex-1 rounded-2xl overflow-hidden relative z-0 border border-gray-100 shadow-inner">
        <MapContainer center={center} zoom={12} scrollWheelZoom={true} className="h-full w-full" ref={mapRef}>
          <TileLayer
            attribution='&copy; OpenStreetMap contributors'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            crossOrigin="anonymous"
          />

          {visualMode === 'standard' && dailyPaths.map((path, idx) => (
            <Polyline 
                key={idx} 
                positions={path.positions} 
                pathOptions={{ 
                  color: path.color, 
                  weight: 4, 
                  opacity: 0.5, 
                  dashArray: '10, 10'
                }} 
            >
              <Popup>{path.label}</Popup>
            </Polyline>
          ))}

          {filteredSamples.map((sample) => (
             <CircleMarker 
                key={sample.id}
                center={[sample.location.lat, sample.location.lng]}
                radius={visualMode === 'heatmap' ? 25 : 8}
                pathOptions={
                  visualMode === 'heatmap' 
                  ? { 
                      fillColor: selectedSampler === 'all' ? '#ef4444' : (samplerColors[sample.samplerId] || '#ef4444'), 
                      color: 'transparent', 
                      fillOpacity: 0.4 
                    }
                  : { 
                      color: getQualityColor(sample), 
                      fillColor: getQualityColor(sample), 
                      fillOpacity: 0.8,
                      weight: 2,
                      stroke: true
                    }
                }
             >
                <Popup className="text-right">
                    <div style={{ textAlign: 'right', direction: 'rtl' }} className="font-sans p-1">
                        <strong className="block border-b mb-2 pb-1 text-blue-900 text-sm">{sample.samplerId}</strong>
                        <div className="text-[11px] space-y-1.5">
                            <p className="font-bold text-gray-600">{new Date(sample.timestamp).toLocaleString('fa-IR')}</p>
                            <div className="grid grid-cols-2 gap-2 mt-2 bg-blue-50/50 p-2 rounded-lg border border-blue-100">
                                <div className="flex flex-col"><span className="text-[9px] text-blue-400">کلر</span><span className="font-black text-blue-700">{sample.metrics.chlorine}</span></div>
                                <div className="flex flex-col"><span className="text-[9px] text-blue-400">pH</span><span className="font-black text-blue-700">{sample.metrics.ph}</span></div>
                                <div className="flex flex-col"><span className="text-[9px] text-blue-400">کدورت</span><span className="font-black text-blue-700">{sample.metrics.turbidity}</span></div>
                                <div className="flex flex-col"><span className="text-[9px] text-blue-400">EC</span><span className="font-black text-blue-700">{sample.metrics.ec}</span></div>
                            </div>
                        </div>
                    </div>
                </Popup>
             </CircleMarker>
          ))}
        </MapContainer>
        
        <div className="absolute bottom-6 left-6 bg-white/95 backdrop-blur-md p-4 rounded-2xl shadow-2xl z-[1000] border border-gray-200 text-[10px] space-y-3 min-w-[140px]">
          <div className="font-black border-b border-gray-100 pb-2 mb-2 text-gray-800 flex items-center gap-2">
            <Filter className="w-3 h-3 text-blue-500" /> راهنمای نقشه
          </div>
          {visualMode === 'standard' ? (
            <>
              <div className="flex items-center gap-3">
                <div className="w-3.5 h-3.5 rounded-full bg-[#10b981]"></div> <span className="font-bold text-gray-600">کیفیت مطلوب</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-3.5 h-3.5 rounded-full bg-[#f59e0b]"></div> <span className="font-bold text-gray-600">نیاز به پایش</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-3.5 h-3.5 rounded-full bg-[#ef4444]"></div> <span className="font-bold text-gray-600">خارج از محدوده</span>
              </div>
            </>
          ) : (
            <div className="flex items-center gap-3">
              <div className="w-5 h-5 rounded-full bg-red-500/40 border border-red-200"></div> <span className="font-bold text-gray-600">تراکم نمونه‌برداری</span>
            </div>
          )}
        </div>
      </div>
      
      {isCapturing && (
        <div className="fixed top-24 left-1/2 -translate-x-1/2 bg-blue-600 text-white px-6 py-3 rounded-2xl shadow-2xl z-[2000] flex items-center gap-3 font-bold text-sm animate-bounce">
          <Loader2 className="w-5 h-5 animate-spin" /> در حال تهیه خروجی تصویری...
        </div>
      )}
    </div>
  );
};

export default MapView;
